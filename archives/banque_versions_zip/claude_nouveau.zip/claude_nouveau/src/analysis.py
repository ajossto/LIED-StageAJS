"""
analysis.py — Analyse statistique et visualisation des résultats de simulation.

Graphiques produits :
  1. macro_overview.png          — Actifs agrégés, volume prêts (axe gauche) +
                                   nombre d'entités vivantes (axe droit)
  2. cascades_rank_size.png      — Taille (ordonnée) en fonction de la fréquence
                                   d'excédance (abscisse), log-log (Zipf)
  3. entity_size_histos.png      — 5 histogrammes horizontaux de la distribution
                                   des tailles d'entités (passif total) :
                                   X = densité de probabilité, Y = taille
  4. hist_evolutif_<x>.png       — Distributions pendant la période de transition
                                   uniquement (avant le premier régime critique)
  5. extraction_power.png        — Puissance extractrice Π = α√P :
                                   médiane, moyenne, max, Q10, Q90
  6. destruction_moving_avg.png  — Moyenne glissante de la destruction de capital
  7. indicateurs_systemiques.png — 5 panneaux temporels des indicateurs agrégés

Usage :
    python analysis.py <dossier_resultats>
    python analysis.py <dossier1> <dossier2>   # comparaison
"""

import csv
import json
import math
import os
import sys
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    MATPLOTLIB_OK = True
except ImportError:
    MATPLOTLIB_OK = False
    print("matplotlib non disponible — seuls les résumés texte seront produits.")


# ============================================================
#  LECTURE DES DONNÉES
# ============================================================

def read_csv(path: str) -> List[dict]:
    """Lit un CSV (ignore les lignes commençant par #). Retourne une liste de dicts."""
    if not os.path.exists(path):
        return []
    lines = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.startswith("#"):
                lines.append(line)
    if not lines:
        return []
    reader = csv.DictReader(lines)
    result = []
    for row in reader:
        converted = {}
        for k, v in row.items():
            try:
                converted[k] = float(v) if "." in v else int(v)
            except (ValueError, TypeError):
                converted[k] = v
        result.append(converted)
    return result


def read_raw_distribution(folder: str, name: str) -> Dict[int, List[float]]:
    """Lit distrib_brute_<name>.csv → {step: [valeurs]}."""
    path = os.path.join(folder, f"distrib_brute_{name}.csv")
    rows = read_csv(path)
    data = defaultdict(list)
    for r in rows:
        data[int(r["step"])].append(float(r["value"]))
    return dict(data)


def read_meta(folder: str) -> dict:
    path = os.path.join(folder, "meta.json")
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ============================================================
#  UTILITAIRES
# ============================================================

def _save(fig, path: str):
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  → {path}")


def _log_binned_histogram(values: List[float], n_bins: int = 30) -> Tuple:
    """
    Histogramme log-binné : bins de largeur égale en espace log.
    Densité = count / (N * largeur_linéaire_du_bin).
    Centre géométrique = √(bord_gauche * bord_droit).
    Retourne (centres, densités, bin_edges) ou (None, None, None).
    """
    pos = [v for v in values if v > 0]
    if len(pos) < 2:
        return None, None, None
    vmin, vmax = min(pos), max(pos)
    if vmin <= 0 or vmax <= vmin:
        return None, None, None
    log_min, log_max = math.log10(vmin), math.log10(vmax)
    if log_max == log_min:
        return None, None, None
    step = (log_max - log_min) / n_bins
    edges = [10 ** (log_min + i * step) for i in range(n_bins + 1)]
    counts = [0] * n_bins
    for v in pos:
        idx = int((math.log10(v) - log_min) / step)
        idx = min(max(idx, 0), n_bins - 1)
        counts[idx] += 1
    total = len(pos)
    centres, densities = [], []
    for i in range(n_bins):
        if counts[i] > 0:
            centre = math.sqrt(edges[i] * edges[i + 1])
            width = edges[i + 1] - edges[i]
            densities.append(counts[i] / (total * width))
            centres.append(centre)
    return centres, densities, edges


def _linear_regression(xs, ys) -> Tuple[float, float]:
    n = len(xs)
    sx, sy = sum(xs), sum(ys)
    sxx = sum(x * x for x in xs)
    sxy = sum(x * y for x, y in zip(xs, ys))
    denom = n * sxx - sx * sx
    if abs(denom) < 1e-12:
        return 0.0, 0.0
    slope = (n * sxy - sx * sy) / denom
    intercept = (sy - slope * sx) / n
    return slope, intercept


def _rolling_mean(values: List[float], window: int) -> List[float]:
    result = []
    for i in range(len(values)):
        lo = max(0, i - window // 2)
        hi = min(len(values), i + window // 2 + 1)
        result.append(sum(values[lo:hi]) / (hi - lo))
    return result


def _detect_transition_end(folder: str) -> int:
    """
    Détecte la fin de la période de transition = premier pas où une cascade apparaît.
    Retourne ce numéro de step, ou -1 si aucune cascade.
    """
    rows = read_csv(os.path.join(folder, "indicateurs_systemiques.csv"))
    for r in rows:
        if r.get("nb_faillites", 0) > 0:
            return int(r["step"])
    return -1


def _subsample(steps: List[int], max_curves: int = 25) -> List[int]:
    """Sous-échantillonne une liste de steps pour ne garder que max_curves éléments."""
    if len(steps) <= max_curves:
        return steps
    step_size = len(steps) // max_curves
    return steps[::step_size][:max_curves]


# ============================================================
#  1. VUE MACRO : ACTIFS, PRÊTS, ENTITÉS
# ============================================================

def plot_macro_overview(folder: str, title_extra: str = ""):
    """
    Axe gauche : actif total agrégé et volume total de prêts
    Axe droit  : nombre d'entités vivantes
    """
    if not MATPLOTLIB_OK:
        return

    rows = read_csv(os.path.join(folder, "indicateurs_systemiques.csv"))
    if not rows:
        return

    steps = [r["step"] for r in rows]
    actifs = [r["actif_total"] for r in rows]
    prets = [r["volume_prets"] for r in rows]
    entites = [r["nb_entites"] for r in rows]

    fig, ax1 = plt.subplots(figsize=(13, 5))
    ax2 = ax1.twinx()

    ax1.plot(steps, actifs, color="#1f77b4", linewidth=1.5, label="Actifs agrégés")
    ax1.plot(steps, prets, color="#9C27B0", linewidth=1.3, linestyle="--", label="Prêts actifs")
    ax1.set_xlabel("Pas de simulation", fontsize=11)
    ax1.set_ylabel("Joules", fontsize=11)

    ax2.plot(steps, entites, color="#e67e22", linewidth=1.3, label="Entités vivantes")
    ax2.set_ylabel("Nombre d'entités vivantes", fontsize=11)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc="upper left")

    title = "Actifs, prêts et population vivante"
    if title_extra:
        title += f" — {title_extra}"
    ax1.set_title(title, fontsize=12)
    ax1.grid(True, alpha=0.25)

    _save(fig, os.path.join(folder, "macro_overview.png"))
# ============================================================
#  2. CASCADES : TAILLE EN FONCTION DE LA FRÉQUENCE (ZIPF)
# ============================================================

def plot_cascades_rank_size(folder: str, title_extra: str = ""):
    """
    Graphique rang-taille des cascades de faillite.

    Axe X : fréquence d'excédance ~ rang / n
    Axe Y : taille de la cascade en joules détruits

    Les deux axes sont en log.
    """
    if not MATPLOTLIB_OK:
        return

    rows = read_csv(os.path.join(folder, "tailles_cascades_brutes.csv"))
    if not rows:
        print("  Pas de données de cascade")
        return

    volumes = sorted(
        [float(r["volume_joules"]) for r in rows if float(r["volume_joules"]) > 0],
        reverse=True,
    )

    n = len(volumes)
    if n < 3:
        print("  Trop peu de cascades pour un graphique rang-taille")
        return

    freq = [(i + 1) / n for i in range(n)]

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(freq, volumes, s=12, alpha=0.65, color="#d62728")

    tail_n = max(3, n // 4)
    log_fx = [math.log10(f) for f in freq[:tail_n]]
    log_vy = [math.log10(v) for v in volumes[:tail_n]]
    slope, intercept = _linear_regression(log_fx, log_vy)

    fit_x = [freq[0], freq[tail_n - 1]]
    fit_y = [10 ** (intercept + slope * math.log10(x)) for x in fit_x]
    ax.plot(fit_x, fit_y, "k--", linewidth=1.4, alpha=0.8, label=f"Pente ≈ {slope:.2f}")

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Fréquence d'excédance", fontsize=11)
    ax.set_ylabel("Taille de la cascade (joules)", fontsize=11)

    title = "Cascades de faillite : taille en fonction de la fréquence"
    if title_extra:
        title += f"\n{title_extra}"
    ax.set_title(title, fontsize=11)
    ax.legend(fontsize=9)
    ax.grid(True, which="both", alpha=0.3)

    _save(fig, os.path.join(folder, "cascades_rank_size.png"))
# ============================================================
#  3. HISTOGRAMMES DE TAILLE DES ENTITÉS (5 INSTANTANÉS)
# ============================================================

def plot_entity_size_histograms(folder: str, n_snapshots: int = 5, title_extra: str = ""):
    """
    5 histogrammes horizontaux de la distribution des tailles d'entités
    mesurées par l'actif total.

    Axe X = densité de probabilité
    Axe Y = taille de l'entité (actif total en joules)

    On garde l'échelle log-log, car les tailles et les densités
    peuvent s'étendre sur plusieurs décades.
    """
    if not MATPLOTLIB_OK:
        return

    data = read_raw_distribution(folder, "actif_total")
    if not data:
        print("  Pas de distribution brute pour actif_total")
        return

    all_steps = sorted(data.keys())
    if len(all_steps) < 2:
        return

    if n_snapshots <= 1:
        selected = [all_steps[-1]]
    else:
        indices = [int(i * (len(all_steps) - 1) / (n_snapshots - 1)) for i in range(n_snapshots)]
        selected = [all_steps[i] for i in indices]

    cmap = plt.cm.viridis
    colors = [cmap(i / max(n_snapshots - 1, 1)) for i in range(len(selected))]

    fig, ax = plt.subplots(figsize=(8, 7))

    for step, color in zip(selected, colors):
        values = [v for v in data[step] if v > 0]
        centres, densities, _ = _log_binned_histogram(values, n_bins=20)
        if centres is None:
            continue
        ax.plot(densities, centres, color=color, linewidth=1.8, alpha=0.85, label=f"Pas {step}")
        ax.scatter(densities, centres, color=color, s=18, zorder=3, alpha=0.75)

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Densité de probabilité", fontsize=11)
    ax.set_ylabel("Actif total (joules)", fontsize=11)

    title = "Distribution des tailles d'entités — 5 instantanés"
    if title_extra:
        title += f"\n{title_extra}"
    ax.set_title(title, fontsize=12)
    ax.legend(fontsize=9, loc="upper right")
    ax.grid(True, which="both", alpha=0.3)

    _save(fig, os.path.join(folder, "entity_size_histos.png"))

# ============================================================
#  4. HISTOGRAMMES ÉVOLUTIFS — PÉRIODE DE TRANSITION
# ============================================================

def plot_evolving_histograms_transition(
    folder: str,
    name: str,
    title_extra: str = "",
    log_x: bool = True,
    log_y: bool = True,
):
    """
    Histogrammes évolutifs d'une grandeur pendant la période de transition
    (avant le premier régime de cascades de faillite).

    Chaque courbe est un instantané de la densité, coloré du bleu (début)
    au rouge (fin de la transition).

    log_x : mettre l'axe des valeurs en log (True pour grandeurs à large plage)
    log_y : mettre l'axe de la densité en log
    """
    if not MATPLOTLIB_OK:
        return
    data = read_raw_distribution(folder, name)
    if not data:
        return

    transition_end = _detect_transition_end(folder)
    all_steps = sorted(data.keys())

    if transition_end > 0:
        transition_steps = [s for s in all_steps if s <= transition_end]
    else:
        transition_steps = all_steps  # pas de cascade = toute la simulation

    if len(transition_steps) < 2:
        print(f"  Trop peu de snapshots en transition pour {name}")
        return

    # Sous-échantillonner si trop de courbes
    plot_steps = _subsample(transition_steps, max_curves=25)
    n = len(plot_steps)

    cmap = plt.cm.cool
    colors = [cmap(i / max(n - 1, 1)) for i in range(n)]

    fig, ax = plt.subplots(figsize=(10, 6))

    for i, step in enumerate(plot_steps):
        values = data[step]
        if len(values) < 2:
            continue
        if log_x:
            centres, densities, _ = _log_binned_histogram(values, n_bins=20)
        else:
            # Bins linéaires
            if not values:
                continue
            vmin, vmax = min(values), max(values)
            if vmax <= vmin:
                continue
            n_bins = 20
            bw = (vmax - vmin) / n_bins
            edges = [vmin + j * bw for j in range(n_bins + 1)]
            counts = [0] * n_bins
            for v in values:
                idx = min(int((v - vmin) / bw), n_bins - 1)
                counts[idx] += 1
            total = len(values)
            centres = [(edges[j] + edges[j + 1]) / 2 for j in range(n_bins)]
            densities = [c / (total * bw) if bw > 0 else 0 for c in counts]

        if centres is None:
            continue
        ax.plot(centres, densities, color=colors[i], alpha=0.7, linewidth=1.0)

    # Colorbar pour le temps de la transition
    sm = plt.cm.ScalarMappable(
        cmap=cmap,
        norm=mcolors.Normalize(vmin=plot_steps[0], vmax=plot_steps[-1]),
    )
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax)
    cbar.set_label("Pas de simulation (transition)", fontsize=9)

    readable_names = {
        "actif_liquide": "Actif liquide L (joules)",
        "actif_total":   "Actif total A (joules)",
        "ratio_L_P":     "Ratio de liquidité L/P",
        "taux_interne":  "Taux interne marginal r*",
        "levier_entite": "Levier individuel P/A",
    }
    xlabel = readable_names.get(name, name)
    ax.set_xlabel(xlabel, fontsize=11)
    ax.set_ylabel("Densité", fontsize=11)

    if log_x:
        ax.set_xscale("log")
    if log_y:
        ax.set_yscale("log")

    title = f"Évolution de la distribution — {xlabel} (transition)"
    if title_extra:
        title += f"\n{title_extra}"
    ax.set_title(title, fontsize=11)
    ax.grid(True, which="both" if (log_x or log_y) else "major", alpha=0.3)

    _save(fig, os.path.join(folder, f"hist_transition_{name}.png"))


# ============================================================
#  5. PUISSANCE EXTRACTRICE
# ============================================================

def plot_extraction_power(folder: str, title_extra: str = ""):
    """
    Évolution temporelle de la puissance extractrice Π_i = α√P_i.

    Courbes : médiane, moyenne, maximum, Q10 (premier décile), Q90 (dernier décile).

    Source : distributions brutes de passif_total + α issu de meta.json.
    La puissance extractrice étant une fonction croissante de P, les statistiques
    sur Π se déduisent directement de celles sur P : Π_i = α√P_i.
    """
    if not MATPLOTLIB_OK:
        return

    meta = read_meta(folder)
    alpha = meta.get("config", {}).get("alpha", 1.0)

    passif_data = read_raw_distribution(folder, "passif_total")
    if not passif_data:
        return

    steps_sorted = sorted(passif_data.keys())
    steps_out = []
    means, medians, maxs, q10s, q90s = [], [], [], [], []

    for step in steps_sorted:
        p_vals = sorted([v for v in passif_data[step] if v > 0])
        if not p_vals:
            continue
        pi_vals = sorted([alpha * math.sqrt(p) for p in p_vals])
        n = len(pi_vals)

        steps_out.append(step)
        means.append(sum(pi_vals) / n)
        medians.append(pi_vals[n // 2])
        maxs.append(pi_vals[-1])
        q10s.append(pi_vals[max(0, int(0.1 * n))])
        q90s.append(pi_vals[min(n - 1, int(0.9 * n))])

    if not steps_out:
        return

    fig, ax = plt.subplots(figsize=(12, 5))

    ax.fill_between(steps_out, q10s, q90s, alpha=0.15, color="#1f77b4", label="Q10–Q90")
    ax.plot(steps_out, medians, color="#1f77b4", linewidth=1.8, label="Médiane")
    ax.plot(steps_out, means,   color="#ff7f0e", linewidth=1.4, linestyle="--", label="Moyenne")
    ax.plot(steps_out, maxs,    color="#d62728", linewidth=1.0, linestyle=":",  label="Maximum")
    ax.plot(steps_out, q10s,    color="#2ca02c", linewidth=1.0, linestyle="-.", label="Q10 (1er décile)")
    ax.plot(steps_out, q90s,    color="#9467bd", linewidth=1.0, linestyle="-.", label="Q90 (dernier décile)")

    ax.set_xlabel("Pas de simulation", fontsize=11)
    ax.set_ylabel(f"Puissance extractrice Π = α√P  (α = {alpha})", fontsize=11)
    title = "Puissance extractrice des entités"
    if title_extra:
        title += f" — {title_extra}"
    ax.set_title(title, fontsize=12)
    ax.legend(fontsize=9, loc="upper left")
    ax.grid(True, alpha=0.25)

    _save(fig, os.path.join(folder, "extraction_power.png"))


# ============================================================
#  6. MOYENNE GLISSANTE DE DESTRUCTION DE CAPITAL
# ============================================================

def plot_destruction_moving_average(folder: str, window: int = 100, title_extra: str = ""):
    """
    Destruction de capital (joules détruits lors des faillites) par pas,
    et sa moyenne glissante centrée sur une fenêtre de `window` pas.

    Permet de visualiser la dynamique lente de la destruction tout en
    conservant l'information sur les épisodes aigus.
    """
    if not MATPLOTLIB_OK:
        return
    rows = read_csv(os.path.join(folder, "indicateurs_systemiques.csv"))
    if not rows:
        return

    steps   = [r["step"] for r in rows]
    volumes = [r["volume_faillites"] for r in rows]
    rolling = _rolling_mean(volumes, window)

    fig, ax = plt.subplots(figsize=(13, 4))

    ax.bar(steps, volumes, width=1.0, color="#e74c3c", alpha=0.35, label="Destruction par pas")
    ax.plot(steps, rolling, color="#c0392b", linewidth=2.0,
            label=f"Moyenne glissante ({window} pas)")

    ax.set_xlabel("Pas de simulation", fontsize=11)
    ax.set_ylabel("Capital détruit (joules)", fontsize=11)
    title = f"Destruction de capital par faillites"
    if title_extra:
        title += f" — {title_extra}"
    ax.set_title(title, fontsize=12)
    ax.legend(fontsize=9)
    ax.grid(True, axis="y", alpha=0.25)

    _save(fig, os.path.join(folder, "destruction_moving_avg.png"))


# ============================================================
#  7. INDICATEURS SYSTÉMIQUES
# ============================================================

def plot_systemic_indicators(folder: str, title_extra: str = ""):
    """
    Évolution temporelle de 5 indicateurs systémiques clés.
    Les cascades sont marquées en rouge sur chaque panneau.
    """
    if not MATPLOTLIB_OK:
        return
    rows = read_csv(os.path.join(folder, "indicateurs_systemiques.csv"))
    if not rows:
        return

    steps      = [r["step"] for r in rows]
    entites    = [r["nb_entites"] for r in rows]
    levier     = [r["levier_systeme"] for r in rows]
    liquidite  = [r["ratio_liquidite"] for r in rows]
    vol_prets  = [r["volume_prets"] for r in rows]
    faillites  = [r["nb_faillites"] for r in rows]
    vol_fail   = [r["volume_faillites"] for r in rows]

    fig, axes = plt.subplots(2, 3, figsize=(16, 8))
    axes = axes.flatten()

    def tracer(ax, y, ylabel, color, title, mark=True):
        ax.plot(steps, y, color=color, linewidth=1.2)
        if mark:
            cx = [s for s, f in zip(steps, faillites) if f > 0]
            cy = [yi for yi, f in zip(y, faillites) if f > 0]
            if cx:
                ax.scatter(cx, cy, color="red", s=14, zorder=5, alpha=0.6)
        ax.set_xlabel("Pas", fontsize=9)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.set_title(title, fontsize=10)
        ax.grid(True, alpha=0.25)

    tracer(axes[0], entites,   "Nb entités",       "#2196F3", "Entités vivantes")
    tracer(axes[1], levier,    "P_total/A_total",  "#FF5722", "Levier système")
    tracer(axes[2], liquidite, "L_total/P_total",  "#4CAF50", "Ratio liquidité")
    tracer(axes[3], vol_prets, "Joules",           "#9C27B0", "Volume prêts actifs", mark=False)

    axes[4].bar(steps, vol_fail, color="#F44336", alpha=0.8, width=1.0)
    axes[4].set_xlabel("Pas", fontsize=9)
    axes[4].set_ylabel("Joules détruits", fontsize=9)
    axes[4].set_title("Volume des cascades (joules)", fontsize=10)
    axes[4].grid(True, axis="y", alpha=0.25)

    concentration = [r["concentration_prets"] for r in rows]
    tracer(axes[5], concentration, "Herfindahl", "#795548", "Concentration réseau de crédit", mark=False)

    global_title = "Indicateurs systémiques"
    if title_extra:
        global_title += f" — {title_extra}"
    fig.suptitle(global_title, fontsize=13, fontweight="bold")
    plt.tight_layout()
    _save(fig, os.path.join(folder, "indicateurs_systemiques.png"))


# ============================================================
#  COMPARAISON MULTI-SCÉNARIOS
# ============================================================

def plot_comparison(folders: List[str], labels: List[str], output_folder: str = "."):
    """Compare plusieurs scénarios sur 4 indicateurs clés."""
    if not MATPLOTLIB_OK or len(folders) < 2:
        return

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))
    axes = axes.flatten()
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]

    for idx, (folder, label) in enumerate(zip(folders, labels)):
        rows = read_csv(os.path.join(folder, "indicateurs_systemiques.csv"))
        if not rows:
            continue
        color = colors[idx % len(colors)]
        steps = [r["step"] for r in rows]
        axes[0].plot(steps, [r["nb_entites"] for r in rows],      label=label, color=color, linewidth=1.3)
        axes[1].plot(steps, [r["levier_systeme"] for r in rows],  label=label, color=color, linewidth=1.3)
        axes[2].plot(steps, [r["ratio_liquidite"] for r in rows], label=label, color=color, linewidth=1.3)
        axes[3].plot(steps, [r["volume_faillites"] for r in rows], label=label, color=color, linewidth=1.3, alpha=0.8)

    configs = [
        ("Entités vivantes",       "Nb entités"),
        ("Levier système (P/A)",   "P_total/A_total"),
        ("Ratio liquidité (L/P)",  "L_total/P_total"),
        ("Volume faillites (joules)", "Joules"),
    ]
    for ax, (title, ylabel) in zip(axes, configs):
        ax.set_title(title, fontsize=11)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.set_xlabel("Pas", fontsize=9)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.25)

    fig.suptitle("Comparaison multi-scénarios", fontsize=13, fontweight="bold")
    plt.tight_layout()
    path = os.path.join(output_folder, "comparaison_scenarios.png")
    _save(fig, path)
    print(f"Comparaison sauvegardée : {path}")


# ============================================================
#  RÉSUMÉS TEXTE
# ============================================================

def summarize_cascades(folder: str) -> str:
    rows = read_csv(os.path.join(folder, "tailles_cascades_brutes.csv"))
    if not rows:
        return "  Aucune cascade enregistrée."
    volumes = sorted([r["volume_joules"] for r in rows if r["volume_joules"] > 0])
    n = len(volumes)
    total = sum(volumes)
    lines = [
        f"  Nombre de cascades       : {n}",
        f"  Volume total détruit     : {total:.1f} joules",
        f"  Volume moyen             : {total/n:.2f} joules",
        f"  Volume médian            : {volumes[n//2]:.2f} joules",
        f"  Volume maximal           : {volumes[-1]:.2f} joules",
        f"  Q90                      : {volumes[int(0.9*n)]:.2f} joules",
        f"  Q99                      : {volumes[min(int(0.99*n), n-1)]:.2f} joules",
    ]
    seuils = [1, 5, 10, 50, 100, 500]
    lines.append("  Distribution (volume > seuil) :")
    for s in seuils:
        nb = sum(1 for v in volumes if v > s)
        if nb > 0:
            lines.append(f"    > {s:6.0f} joules : {nb:5d} cascades ({100*nb/n:.1f}%)")
    return "\n".join(lines)


# ============================================================
#  POINT D'ENTRÉE
# ============================================================

def analyze_folder(folder: str, verbose: bool = True):
    """Lance l'analyse complète d'un dossier de simulation."""
    if not os.path.exists(folder):
        print(f"Dossier introuvable : {folder}")
        return

    meta = read_meta(folder)
    label = meta.get("label", os.path.basename(folder))

    if verbose:
        print(f"\nAnalyse : {folder}")
        print(f"Label   : {label}")
        if meta.get("summary"):
            for k, v in meta["summary"].items():
                print(f"  {k}: {v}")

    transition_end = _detect_transition_end(folder)
    if transition_end > 0:
        print(f"\n  Fin de transition détectée au pas {transition_end}")
    else:
        print("\n  Aucune cascade détectée — toute la simulation est 'transition'")

    print("\nStatistiques des cascades :")
    print(summarize_cascades(folder))

    if MATPLOTLIB_OK:
        print("\nGénération des graphiques :")

        # 1. Vue macro
        plot_macro_overview(folder, title_extra=label)

        # 2. Distribution Zipf des cascades
        plot_cascades_rank_size(folder, title_extra=label)

        # 3. Distribution des tailles d'entités (5 instantanés)
        plot_entity_size_histograms(folder, n_snapshots=5, title_extra=label)

        # 4. Histogrammes évolutifs pendant la transition
        #    - actif_liquide  : log-log (plage large)
        #    - ratio_L_P      : X linéaire (borné), Y log
        #    - taux_interne   : log-log (plage large)
        #    - levier_entite  : linéaire (P/A ≈ 0–1+, pas de log nécessaire)
        plot_evolving_histograms_transition(folder, "actif_liquide", label, log_x=True,  log_y=True)
        plot_evolving_histograms_transition(folder, "actif_total",   label, log_x=True,  log_y=True)
        plot_evolving_histograms_transition(folder, "taux_interne",  label, log_x=True,  log_y=True)
        plot_evolving_histograms_transition(folder, "levier_entite", label, log_x=False, log_y=False)

        # 5. Puissance extractrice
        plot_extraction_power(folder, title_extra=label)

        # 6. Moyenne glissante de destruction de capital
        plot_destruction_moving_average(folder, window=100, title_extra=label)

        # 7. Indicateurs systémiques
        plot_systemic_indicators(folder, title_extra=label)

        print("Graphiques générés.")


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        print("Usage : python analysis.py <dossier> [dossier2 ...]")
        sys.exit(1)

    if len(args) == 1:
        analyze_folder(args[0])
    else:
        labels_list = [read_meta(d).get("label", os.path.basename(d)) for d in args]
        for d in args:
            analyze_folder(d)
        print("\nComparaison multi-scénarios :")
        plot_comparison(args, labels_list, output_folder=".")
